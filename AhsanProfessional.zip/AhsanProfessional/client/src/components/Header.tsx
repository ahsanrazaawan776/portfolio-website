import React, { useState } from 'react';

interface HeaderProps {
  activeSection: string;
}

const Header: React.FC<HeaderProps> = ({ activeSection }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
    
    if (mobileMenuOpen) {
      setMobileMenuOpen(false);
    }
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'experience', label: 'Experience' },
    { id: 'skills', label: 'Skills' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'contact', label: 'Contact' }
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-white bg-opacity-95 shadow-sm z-50">
      <nav className="container mx-auto px-4 py-4 flex items-center justify-between">
        <a 
          href="#home" 
          className="text-xl font-bold text-primary"
          onClick={(e) => handleNavClick(e, 'home')}
        >
          Ahsan Raza<span className="text-dark">.</span>
        </a>
        
        {/* Desktop Navigation */}
        <div className="hidden md:flex space-x-8">
          {navItems.map(item => (
            <a 
              key={item.id}
              href={`#${item.id}`} 
              className={activeSection === item.id ? "navbar-active hover:text-primary transition" : "hover:text-primary transition"}
              onClick={(e) => handleNavClick(e, item.id)}
            >
              {item.label}
            </a>
          ))}
        </div>
        
        {/* Mobile Menu Button */}
        <button 
          onClick={toggleMobileMenu}
          className="md:hidden text-dark focus:outline-none"
        >
          <i className="fas fa-bars text-xl"></i>
        </button>
        
        {/* Contact Button */}
        <a 
          href="#contact" 
          className="hidden md:block bg-primary hover:bg-blue-600 text-white px-6 py-2 rounded-full transition"
          onClick={(e) => handleNavClick(e, 'contact')}
        >
          Contact Me
        </a>
      </nav>
      
      {/* Mobile Navigation */}
      <div className={`md:hidden bg-white px-4 py-2 shadow-md ${mobileMenuOpen ? 'block' : 'hidden'}`}>
        <div className="flex flex-col space-y-3 pb-3">
          {navItems.map(item => (
            <a 
              key={item.id}
              href={`#${item.id}`} 
              className={activeSection === item.id ? "navbar-active hover:text-primary transition py-2" : "hover:text-primary transition py-2"}
              onClick={(e) => handleNavClick(e, item.id)}
            >
              {item.label}
            </a>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;
