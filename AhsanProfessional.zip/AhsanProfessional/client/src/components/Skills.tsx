import React from 'react';
import { motion } from 'framer-motion';

interface SkillCategory {
  id: number;
  title: string;
  icon: string;
  iconClass: string;
  bgClass: string;
  fillClass: string;
  skills: {
    name: string;
    percentage: number;
  }[];
}

const skillsData: SkillCategory[] = [
  {
    id: 1,
    title: "Digital Marketing",
    icon: "fas fa-bullhorn",
    iconClass: "text-primary",
    bgClass: "bg-blue-100",
    fillClass: "bg-primary",
    skills: [
      { name: "Social Media Marketing", percentage: 90 },
      { name: "SEO & SEM", percentage: 85 },
      { name: "Content Strategy", percentage: 80 },
      { name: "Email Marketing", percentage: 75 }
    ]
  },
  {
    id: 2,
    title: "Graphic Design",
    icon: "fas fa-palette",
    iconClass: "text-[#10B981]",
    bgClass: "bg-green-100",
    fillClass: "bg-[#10B981]",
    skills: [
      { name: "Logo Design", percentage: 95 },
      { name: "Brand Identity", percentage: 90 },
      { name: "Social Media Graphics", percentage: 85 },
      { name: "UI/UX Design", percentage: 75 }
    ]
  },
  {
    id: 3,
    title: "E-Commerce",
    icon: "fas fa-store",
    iconClass: "text-[#6366F1]",
    bgClass: "bg-indigo-100",
    fillClass: "bg-[#6366F1]",
    skills: [
      { name: "Product Listing Optimization", percentage: 90 },
      { name: "Conversion Optimization", percentage: 85 },
      { name: "Marketplace Management", percentage: 80 },
      { name: "Customer Experience Design", percentage: 75 }
    ]
  },
  {
    id: 4,
    title: "Business Management",
    icon: "fas fa-chart-line",
    iconClass: "text-pink-500",
    bgClass: "bg-pink-100",
    fillClass: "bg-pink-500",
    skills: [
      { name: "Strategic Planning", percentage: 85 },
      { name: "Data Analysis", percentage: 80 },
      { name: "Project Management", percentage: 85 },
      { name: "Client Relationship", percentage: 90 }
    ]
  }
];

const Skills: React.FC = () => {
  return (
    <section id="skills" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-2">My Skills</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-xl mx-auto">
            A comprehensive overview of my professional capabilities and expertise.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {skillsData.map((category, index) => (
            <motion.div 
              key={category.id}
              className="bg-light rounded-xl p-8 shadow-sm hover:shadow-md transition"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="flex items-center mb-6">
                <div className={`w-12 h-12 ${category.bgClass} rounded-full flex items-center justify-center mr-4`}>
                  <i className={`${category.icon} ${category.iconClass} text-xl`}></i>
                </div>
                <h3 className="text-xl font-semibold">{category.title}</h3>
              </div>
              
              <div className="space-y-4">
                {category.skills.map((skill, skillIndex) => (
                  <div key={skillIndex}>
                    <div className="flex justify-between mb-1">
                      <span className="text-gray-700">{skill.name}</span>
                      <span className="text-gray-500">{skill.percentage}%</span>
                    </div>
                    <motion.div 
                      className="progress-bar"
                      initial={{ opacity: 0 }}
                      whileInView={{ opacity: 1 }}
                      viewport={{ once: true }}
                      transition={{ duration: 0.5, delay: 0.3 + skillIndex * 0.1 }}
                    >
                      <motion.div 
                        className={`progress-bar-fill ${category.fillClass}`} 
                        style={{ width: `${skill.percentage}%` }}
                        initial={{ width: 0 }}
                        whileInView={{ width: `${skill.percentage}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8, delay: 0.4 + skillIndex * 0.1 }}
                      ></motion.div>
                    </motion.div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
