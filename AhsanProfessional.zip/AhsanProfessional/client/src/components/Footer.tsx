import React from 'react';

const Footer: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'experience', label: 'Experience' },
    { id: 'skills', label: 'Skills' },
    { id: 'portfolio', label: 'Portfolio' },
    { id: 'contact', label: 'Contact' }
  ];

  const socialLinks = [
    { icon: 'fab fa-linkedin-in', url: 'https://www.linkedin.com/in/ahsan-raza/' },
    { icon: 'fab fa-facebook-f', url: 'https://www.facebook.com/ahsanrazaawan6/' },
    { icon: 'fas fa-envelope', url: 'mailto:b.ahsanraza@gmail.com' }
  ];

  return (
    <footer className="bg-gray-900 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="mb-6 md:mb-0">
            <a 
              href="#home" 
              className="text-2xl font-bold"
              onClick={(e) => handleNavClick(e, 'home')}
            >
              Ahsan Raza<span className="text-primary">.</span>
            </a>
            <p className="text-gray-400 mt-2">Digital Marketer & Graphic Designer</p>
          </div>
          
          <div className="flex flex-wrap justify-center gap-4 mb-6 md:mb-0">
            {navItems.map(item => (
              <a 
                key={item.id}
                href={`#${item.id}`} 
                className="text-gray-400 hover:text-white transition"
                onClick={(e) => handleNavClick(e, item.id)}
              >
                {item.label}
              </a>
            ))}
          </div>
          
          <div>
            <div className="flex space-x-4">
              {socialLinks.map((link, index) => (
                <a 
                  key={index}
                  href={link.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 hover:bg-primary rounded-full flex items-center justify-center transition"
                >
                  <i className={link.icon}></i>
                </a>
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-gray-400">&copy; {new Date().getFullYear()} Ahsan Raza. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
