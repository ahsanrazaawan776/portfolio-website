import React, { useState } from 'react';
import { motion } from 'framer-motion';

interface PortfolioItem {
  id: number;
  title: string;
  description: string;
  category: string;
  imageUrl: string;
}

const portfolioData: PortfolioItem[] = [
  {
    id: 1,
    title: "Modern Brand Identity",
    description: "Complete brand identity design for a tech startup",
    category: "branding",
    imageUrl: "https://images.unsplash.com/photo-1546558868-8451971c32dd?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 2,
    title: "Social Media Campaign",
    description: "Comprehensive social media strategy with creative assets",
    category: "marketing",
    imageUrl: "https://images.unsplash.com/photo-1568992687947-868a62a9f521?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1332&q=80"
  },
  {
    id: 3,
    title: "E-Commerce Store Design",
    description: "Online store with optimized product listings and checkout",
    category: "ecommerce",
    imageUrl: "https://images.unsplash.com/photo-1523206489230-c012c64b2b48?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80"
  },
  {
    id: 4,
    title: "Brand Guidelines",
    description: "Comprehensive brand manual for consistent marketing",
    category: "branding",
    imageUrl: "https://images.unsplash.com/photo-1583292650898-7d22cd27ca6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
  },
  {
    id: 5,
    title: "Email Marketing Campaign",
    description: "Sequence of email designs with high conversion rates",
    category: "marketing",
    imageUrl: "https://images.unsplash.com/photo-1611162616475-46b635cb6868?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1074&q=80"
  },
  {
    id: 6,
    title: "Product Photography",
    description: "Creative product imagery for e-commerce platform",
    category: "ecommerce",
    imageUrl: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1170&q=80"
  }
];

interface FilterButtonProps {
  category: string;
  activeFilter: string;
  onClick: (category: string) => void;
  children: React.ReactNode;
  isFirst?: boolean;
  isLast?: boolean;
}

const FilterButton: React.FC<FilterButtonProps> = ({ 
  category, 
  activeFilter, 
  onClick, 
  children, 
  isFirst = false, 
  isLast = false 
}) => {
  const isActive = activeFilter === category;
  
  let className = "px-4 py-2 text-sm font-medium focus:outline-none";
  
  if (isActive) {
    className += " text-white bg-primary";
  } else {
    className += " text-gray-700 bg-white hover:bg-gray-100";
  }
  
  if (isFirst) className += " rounded-l-lg";
  if (isLast) className += " rounded-r-lg";
  
  return (
    <button
      type="button"
      className={className}
      onClick={() => onClick(category)}
    >
      {children}
    </button>
  );
};

const Portfolio: React.FC = () => {
  const [activeFilter, setActiveFilter] = useState("all");

  const handleFilterClick = (filter: string) => {
    setActiveFilter(filter);
  };

  const filteredItems = activeFilter === "all" 
    ? portfolioData 
    : portfolioData.filter(item => item.category === activeFilter);

  return (
    <section id="portfolio" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-2">My Portfolio</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-xl mx-auto">
            Explore my recent work in digital marketing, graphic design, and branding projects.
          </p>
        </motion.div>
        
        <div className="mb-8 flex justify-center">
          <div className="inline-flex rounded-md shadow-sm" role="group">
            <FilterButton 
              category="all" 
              activeFilter={activeFilter} 
              onClick={handleFilterClick}
              isFirst={true}
            >
              All Projects
            </FilterButton>
            <FilterButton 
              category="branding" 
              activeFilter={activeFilter} 
              onClick={handleFilterClick}
            >
              Branding
            </FilterButton>
            <FilterButton 
              category="marketing" 
              activeFilter={activeFilter} 
              onClick={handleFilterClick}
            >
              Marketing
            </FilterButton>
            <FilterButton 
              category="ecommerce" 
              activeFilter={activeFilter} 
              onClick={handleFilterClick}
              isLast={true}
            >
              E-Commerce
            </FilterButton>
          </div>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: {
              opacity: 1,
              transition: {
                staggerChildren: 0.1
              }
            }
          }}
        >
          {filteredItems.map((item) => (
            <motion.div 
              key={item.id}
              className="portfolio-item group"
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.5 } }
              }}
            >
              <div className="relative overflow-hidden rounded-xl shadow-sm">
                <img 
                  src={item.imageUrl} 
                  alt={item.title} 
                  className="w-full h-64 object-cover transition duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-0 group-hover:opacity-90 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <h3 className="text-white text-xl font-semibold mb-2">{item.title}</h3>
                  <p className="text-gray-200 mb-4">{item.description}</p>
                  <a href="#" className="inline-flex items-center text-white hover:text-primary transition">
                    <span>View Details</span>
                    <i className="fas fa-arrow-right ml-2"></i>
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

export default Portfolio;
