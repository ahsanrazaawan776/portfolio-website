import React from 'react';
import { motion } from 'framer-motion';

const About: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row">
          <motion.div 
            className="md:w-1/3 mb-10 md:mb-0"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-3xl font-bold mb-2">About Me</h2>
            <div className="w-20 h-1 bg-primary mb-6"></div>
            <p className="text-gray-600 mb-6">
              Get to know me better and learn about my professional journey.
            </p>
            <div className="flex space-x-4 mb-6">
              <a href="https://www.linkedin.com/in/ahsan-raza/" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-primary transition">
                <i className="fab fa-linkedin text-2xl"></i>
              </a>
              <a href="https://www.facebook.com/ahsanrazaawan6/" target="_blank" rel="noopener noreferrer" className="text-gray-600 hover:text-primary transition">
                <i className="fab fa-facebook text-2xl"></i>
              </a>
              <a href="mailto:b.ahsanraza@gmail.com" className="text-gray-600 hover:text-primary transition">
                <i className="fas fa-envelope text-2xl"></i>
              </a>
            </div>
            <a 
              href="#experience" 
              className="text-primary hover:text-blue-700 font-medium inline-flex items-center transition"
              onClick={(e) => handleNavClick(e, 'experience')}
            >
              <span>View My Experience</span>
              <i className="fas fa-arrow-right ml-2"></i>
            </a>
          </motion.div>
          <motion.div 
            className="md:w-2/3 md:pl-16"
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <div className="bg-light rounded-xl p-8 shadow-sm">
              <h3 className="text-xl font-semibold mb-4">Professional Background</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                I am a versatile professional with extensive experience in digital marketing, graphic design, and e-commerce. 
                My journey started in data coordination roles, which provided me with strong analytical skills that I now 
                leverage in my marketing strategies.
              </p>
              <p className="text-gray-600 mb-6 leading-relaxed">
                As a business owner at NaturalSaltLamp.Shop, I've combined my passions for digital marketing and product 
                branding to create a successful e-commerce venture. I specialize in creating cohesive digital experiences 
                that align with business goals and resonate with target audiences.
              </p>
              <div className="grid grid-cols-2 gap-6 mt-8">
                <div>
                  <p className="text-gray-500 mb-1">Email</p>
                  <p className="font-medium">b.ahsanraza@gmail.com</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Role</p>
                  <p className="font-medium">Digital Marketer & Designer</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Location</p>
                  <p className="font-medium">Islamabad, Pakistan</p>
                </div>
                <div>
                  <p className="text-gray-500 mb-1">Experience</p>
                  <p className="font-medium">5+ Years</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default About;
