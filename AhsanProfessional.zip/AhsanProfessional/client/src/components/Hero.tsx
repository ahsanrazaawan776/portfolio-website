import React from 'react';
import { motion } from 'framer-motion';
import profilePhoto from '../assets/profile-photo.jpg';

const Hero: React.FC = () => {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, targetId: string) => {
    e.preventDefault();
    const target = document.getElementById(targetId);
    
    if (target) {
      window.scrollTo({
        top: target.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="pt-28 pb-20 md:pt-40 md:pb-32 bg-gradient-to-br from-blue-50 to-white">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <motion.div 
            className="md:w-1/2 mb-10 md:mb-0 md:pr-10"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Hi, I'm <span className="text-primary">Ahsan Raza</span>
            </h1>
            <h2 className="text-xl md:text-2xl text-gray-600 mb-6">
              Digital Marketer | Graphic Designer | Business Owner
            </h2>
            <p className="text-gray-600 mb-8 leading-relaxed">
              I create impactful digital experiences through strategic marketing 
              and creative design solutions that help businesses grow.
            </p>
            <div className="flex space-x-4">
              <a 
                href="#portfolio" 
                className="bg-primary hover:bg-blue-600 text-white px-6 py-3 rounded-full font-medium transition"
                onClick={(e) => handleNavClick(e, 'portfolio')}
              >
                View My Work
              </a>
              <a 
                href="#contact" 
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-3 rounded-full font-medium transition"
                onClick={(e) => handleNavClick(e, 'contact')}
              >
                Contact Me
              </a>
            </div>
          </motion.div>
          <motion.div 
            className="md:w-1/2 flex justify-center md:justify-end"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <div className="relative">
              <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-white shadow-lg">
                <img 
                  src={profilePhoto} 
                  alt="Ahsan Raza" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -right-4 bg-white rounded-full p-3 shadow-md">
                <div className="bg-[#10B981] text-white rounded-full w-16 h-16 flex items-center justify-center">
                  <i className="fas fa-check text-2xl"></i>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
