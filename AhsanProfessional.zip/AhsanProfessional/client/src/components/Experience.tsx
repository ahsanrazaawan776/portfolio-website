import React from 'react';
import { motion } from 'framer-motion';

interface ExperienceItem {
  id: number;
  title: string;
  company: string;
  period: string;
  description: string;
  skills: string[];
  current: boolean;
}

const experienceData: ExperienceItem[] = [
  {
    id: 1,
    title: "Business Owner",
    company: "NaturalSaltLamp.Shop",
    period: "Current",
    description: "Founded and operate an e-commerce business selling premium quality salt lamps. Manage all aspects of the business including product sourcing, digital marketing, website design, and customer service.",
    skills: ["E-commerce", "Digital Marketing", "Product Branding", "SEO"],
    current: true
  },
  {
    id: 2,
    title: "Digital Marketing & Data Coordinator",
    company: "Earnet Pakistan",
    period: "2021 - 2023",
    description: "Led digital marketing campaigns and managed data analytics to drive business growth. Created comprehensive marketing strategies and designed promotional materials to enhance brand visibility.",
    skills: ["Campaign Management", "Data Analysis", "Content Creation"],
    current: false
  },
  {
    id: 3,
    title: "Lab Assistant & Data Coordinator",
    company: "Iqra College of Technology",
    period: "2019 - 2021",
    description: "Assisted in laboratory operations and coordinated data management processes. Developed and maintained database systems, created detailed reports, and provided technical support to students.",
    skills: ["Data Management", "Technical Support", "Reporting"],
    current: false
  },
  {
    id: 4,
    title: "Data Operator",
    company: "Mohsin E Azam Travel and Tours",
    period: "2018 - 2019",
    description: "Managed data entry and processing for travel arrangements and bookings. Coordinated with clients and vendors to ensure accurate information handling and assisted in creating marketing materials for tours.",
    skills: ["Data Entry", "Client Coordination", "Marketing Materials"],
    current: false
  }
];

const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4">
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="text-3xl font-bold mb-2">Professional Experience</h2>
          <div className="w-20 h-1 bg-primary mx-auto mb-6"></div>
          <p className="text-gray-600 max-w-xl mx-auto">
            A timeline of my professional journey and key roles that have shaped my expertise.
          </p>
        </motion.div>

        <div className="max-w-3xl mx-auto">
          {experienceData.map((experience, index) => (
            <motion.div 
              key={experience.id}
              className={`timeline-item relative pl-10 ${index !== experienceData.length - 1 ? 'pb-16' : ''}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="timeline-dot"></div>
              <div className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <h3 className="text-xl font-semibold text-gray-800">{experience.title}</h3>
                  <span className={`px-3 py-1 ${experience.current ? 'bg-blue-100 text-primary' : 'bg-gray-200 text-gray-700'} rounded-full text-sm font-medium`}>
                    {experience.period}
                  </span>
                </div>
                <h4 className="text-lg text-gray-600 mb-3">{experience.company}</h4>
                <p className="text-gray-600 mb-5">
                  {experience.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {experience.skills.map((skill, skillIndex) => (
                    <span key={skillIndex} className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-xs">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
